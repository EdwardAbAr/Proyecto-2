package Camara;

public class Tesseract {
}
