package Servidor;

public class NodoPila {
    NodoArbol dato;
    NodoPila siguiente;

    public NodoPila (NodoArbol x){
        dato = x;
        siguiente = null;
    }
}
